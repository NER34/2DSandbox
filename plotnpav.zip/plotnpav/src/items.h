#ifndef ITEMS
#define ITEMS

#include "iblock.h"
#include "itree.h"
#include "ifishing_row.h"
#include "ifood.h"

#endif
