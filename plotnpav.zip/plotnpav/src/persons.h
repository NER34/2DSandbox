#ifndef PERSONS
#define PERSONS

#include "enemy.h"
#include "player.h"

#endif
